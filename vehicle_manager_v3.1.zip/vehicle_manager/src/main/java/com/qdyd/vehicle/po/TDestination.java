package com.qdyd.vehicle.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@Data
@TableName(value = "t_destination")
public class TDestination {

    @TableField("t_des_id")
    private String desId;
    @TableField("t_des_name")
    private String desName;
    @TableField("t_des_time")
    private Date desTime;
	public TDestination(String desId, String desName, Date desTime) {
		super();
		this.desId = desId;
		this.desName = desName;
		this.desTime = desTime;
	}
	public String getDesId() {
		return desId;
	}
	public void setDesId(String desId) {
		this.desId = desId;
	}
	public String getDesName() {
		return desName;
	}
	public void setDesName(String desName) {
		this.desName = desName;
	}
	public Date getDesTime() {
		return desTime;
	}
	public void setDesTime(Date desTime) {
		this.desTime = desTime;
	}
	public TDestination() {
		super();
	}
	@Override
	public String toString() {
		return "TDestination [desId=" + desId + ", desName=" + desName + ", desTime=" + desTime + "]";
	}

}
