package com.qdyd.vehicle;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 数据库备份
 */
public class DbBeifei {

}
