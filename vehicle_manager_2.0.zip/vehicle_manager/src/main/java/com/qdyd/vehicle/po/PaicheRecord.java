package com.qdyd.vehicle.po;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.util.Date;

@Data
public class PaicheRecord {

    private String paicheno;//派车单号
    private String paichedate;//开单日期
    private String department;//用车人部门
    private String useMan;//用车人
    private String cause;//用车事由
    private String man;//人数
    private String weight;//载重
    private String destination;//目的地
    private String carNo;//车牌号
    private String carType;//车辆类型
    private String driverName;//驾驶员
    private String comMander;//派车人
    private String auditLeaderShip;//审核领导
    private String storageTime;//开车时间
    private String returnTime;//回厂时间
    private String drivingTime;//行车时间
    private Integer mileage;//行驶里程
    private Integer status;


}
