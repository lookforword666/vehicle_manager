package com.qdyd.vehicle.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@Data
@TableName(value = "t_destination")
public class TDestination {

    @TableField("t_des_id")
    private String desId;
    @TableField("t_des_name")
    private String desName;
    @TableField("t_des_time")
    private Date desTime;

}
