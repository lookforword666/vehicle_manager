package com.qdyd.vehicle.po;

import lombok.Data;

import java.util.Date;

@Data
public class TDuty {
    private String dutyId;
    private String dutyCompany;
    private Date dutyCreateDate;
    private String dutyWeek;
    private String dutyDate;
    private String dutyLeader;
    private String dutyMan;

    public TDuty(Object[] values){
        this.dutyCompany=values[1].toString();
        this.dutyDate=values[2].toString();
        this.dutyWeek=values[3].toString();
        this.dutyLeader=values[4].toString();
        this.dutyMan=values[5].toString();
    }
}
