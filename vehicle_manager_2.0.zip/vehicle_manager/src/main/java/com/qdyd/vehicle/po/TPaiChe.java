package com.qdyd.vehicle.po;

import java.util.Date;

import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 派车单表
 */
@Data
@ToString
@Entity
@Table(name = "t_paiche")
public class TPaiChe {

	@Id
	@Column(name ="t_paiche_id")
	private String paicheId;//'要删除的id'

	@Column(name ="t_no")
	private String no;

	@Column(name ="t_date")
	private Date date;

	@Column(name ="t_use_man")
	private String useMan;

	@Column(name = "t_dept_id")
	private String deptId;

	@Column(name ="t_cause")
	private String cause;

	@Column(name ="t_car_type")
	private String carType;

	@Column(name = "t_man")
	private String man;

	@Column(name ="t_weight")
	private Integer weight;

	@Column(name ="t_car_id")
	private String carId;

	@Column(name ="t_driver_id")
	private String driverId;

	@Column(name ="t_des_id")
	private String destination;

	@Column(name ="t_drive_time")
	private String driveTime;

	@Column(name ="t_go_mileage")
	private Integer goMileage;

	@Column(name ="t_come_mileage")
	private Integer comeMileage;

	@Column(name ="t_mileage")
	private Integer mileage;

	@Column(name ="t_com_mander")
	private String comMander;

	@Column(name ="t_audit_leadership")
	private String auditLeaderShip;

	// 实际返场时间
	@Column(name ="t_return_time")
	private String returnTime;

	// 实际出场时间
	@Column(name ="t_storage_time")
	private String storageTime;

	@Column(name = "t_guji_reture_time")
	private String gujiRetureTime;

	@Column(name = "t_guji_storage_time")
	private String gujiStorageTime;

	@Column(name ="t_update_time")
	private Date updateTime;

	@Column(name ="t_delete_time")
	private Date deleteTime;

	@Column(name ="t_data_status")
	private Integer dataStatus;

	@Column(name ="t_remark")
	private String remark;

	@Column(name = "t_status")
	private String status;// 派车单审核状态 0：待审  1 审核未通过  2 审核通过

//	private String sTime;
//
//	private String rTime;




}
