package com.qdyd.vehicle.po;

import lombok.Data;

import java.util.Date;

@Data
public class PaicheVo {

    private String paicheId;//'要删除的id'
    private String no;
    private Date date;
    private String useMan;
    private String deptId;
    private String cause;
    private Integer weight;
    private String carId;
    private String driverId;
    private String destination;
    private String driveTime;
    private Integer goMileage;
    private Integer comeMileage;
    private Integer mileage;
    private String comMander;
    private String auditLeaderShip;
    // 实际返场时间
    private String returnTime;
    // 实际出场时间
    private String storageTime;
    private String gujiRetureTime;
    private String gujiStorageTime;
    private String remark;

    private String useName;
    private String driverName;
    private String matter;
    private String carNo;
    private String desName;
    private Integer dataStatus;
    private String carType;

}
